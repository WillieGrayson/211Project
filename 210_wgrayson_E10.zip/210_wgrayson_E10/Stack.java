public class Stack<E>
{
  private int size;
  private E[] list;
  private int location;
  
  public Stack(int size)
  {
    this.size = size;
    this.location = -1;
    list = (E[]) new Object[size];
  }
  public boolean push(E value)
  {
    System.out.println("Pushed the element "+value+" onto the stack");
    list[++this.location] = value;
    return true;
  }
  public E pop()
  {
    if(this.location==-1)
      return null;
    E value = list[this.location];
    System.out.println("Current size of stack: "+this.location);
    this.location--;
    return value;
  }
  
}