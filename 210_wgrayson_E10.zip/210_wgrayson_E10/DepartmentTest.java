public class DepartmentTest
{
  public static void main(String args[])
  {
    Department<Integer,String> depart = new Department<Integer,String>(5,"Hello");
    depart.getCode();
    depart.getName();
  }
}