public class Department<T,E>
{
  private T code;
  private E name;
  public Department(T code, E name)
  {
    this.code = code;
    this.name = name;
  }
  public T getCode()
  {
    System.out.println(this.code.getClass().getName());
    System.out.println(this.code);
    return this.code;
  }
  public E getName()
  {
     System.out.println(this.name.getClass().getName());
     System.out.println(this.name);
     return this.name;
  }
}