public class TestStack
{
  public static void main(String args[])
  {
    Stack<Integer> stack = new Stack<Integer>(5);
    stack.push(1);
    stack.push(2);
    stack.push(3);
    stack.push(4);
    stack.push(5);
    System.out.println("Popped "+stack.pop());
    Stack<String> secondStack = new Stack<String>(5);
    secondStack.push("a");
    secondStack.push("b");
    secondStack.push("c");
    secondStack.push("d");
    secondStack.push("e");
    System.out.println("Popped "+secondStack.pop());
    
  }
}